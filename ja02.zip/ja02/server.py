from flask import Flask, render_template, request, jsonify
import pickle
import random
import os
from datetime import datetime

app = Flask(__name__)

Q_TABLE_FILE = "q_table.pkl"
EPSILON = 0.01  
ALPHA = 0.2     
GAMMA = 0.95 


q_table = {}
if os.path.exists(Q_TABLE_FILE):
    with open(Q_TABLE_FILE, "rb") as f:
        q_table = pickle.load(f)

history = []
board = [' '] * 9
player = "X"
ai = "O"

def save_q_table():
    with open(Q_TABLE_FILE, "wb") as f:
        pickle.dump(q_table, f)

def get_state_key(board):
    return ''.join(board)

def check_winner(board):
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]
    for a,b,c in wins:
        if board[a] == board[b] == board[c] and board[a] != ' ':
            return board[a]
    if ' ' not in board:
        return 'tie'
    return None

def best_move(board):
    state = get_state_key(board)
    available = [i for i in range(9) if board[i] == ' ']
    if random.random() < EPSILON:
        return random.choice(available)
    q_values = [q_table.get((state, a), 0) for a in available]
    max_q = max(q_values)
    best = [a for a, q in zip(available, q_values) if q == max_q]
    return random.choice(best)

def update_q_table(prev_state, action, reward, new_state, done):
    old_q = q_table.get((prev_state, action), 0)
    future_q = 0 if done else max([q_table.get((new_state, a), 0)
                                   for a in range(9) if new_state[a] == ' '], default=0)
    q_table[(prev_state, action)] = old_q + ALPHA * (reward + GAMMA * future_q - old_q)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/rps", methods=["POST"])
def rps():
    user_choice = request.json["choice"]
    choices = ["rock", "paper", "scissors"]
    ai_choice = random.choice(choices)

    wins = {"rock": "scissors", "scissors": "paper", "paper": "rock"}
    if user_choice == ai_choice:
        result = "tie"
    elif wins[user_choice] == ai_choice:
        result = "user"
    else:
        result = "ai"

    return jsonify({"result": result, "ai_choice": ai_choice})

@app.route("/new_game", methods=["POST"])
def new_game():
    global board
    board = [' '] * 9
    return jsonify({"board": board})

@app.route("/play", methods=["POST"])
def play():
    global board
    data = request.json
    move = data["move"]
    prev_state = get_state_key(board)

    if move != -1:
        if board[move] == ' ':
            board[move] = player
            winner = check_winner(board)
            if winner:
                reward = 1 if winner == player else 0
                update_q_table(prev_state, move, reward, get_state_key(board), True)
                history.append({"id": len(history)+1, "result": winner, "date": str(datetime.now())})
                save_q_table()
                return jsonify({"board": board, "winner": winner})

    ai_move = best_move(board)
    board[ai_move] = ai
    new_state = get_state_key(board)
    winner = check_winner(board)
    reward = 0
    done = False
    if winner:
        reward = -1 if winner == player else 1 if winner == ai else 0.5
        done = True
        history.append({"id": len(history)+1, "result": winner, "date": str(datetime.now())})
        save_q_table()
    update_q_table(prev_state, ai_move, reward, new_state, done)
    return jsonify({"board": board, "winner": winner if done else None})

@app.route("/history")
def get_history():
    return jsonify(history[-10:])

if __name__ == "__main__":
    app.run(debug=True)
