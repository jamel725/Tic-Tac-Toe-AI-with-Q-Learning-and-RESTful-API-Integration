import pickle
import random
import os

Q_TABLE_FILE = "q_table.pkl"
EPISODES = 100000  # ככל שיותר - AI יהיה חזק יותר
EPSILON = 0.1
ALPHA = 0.2
GAMMA = 0.95

q_table = {}
if os.path.exists(Q_TABLE_FILE):
    with open(Q_TABLE_FILE, "rb") as f:
        q_table = pickle.load(f)

def get_state_key(board):
    return ''.join(board)

def check_winner(board):
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]
    for a,b,c in wins:
        if board[a] == board[b] == board[c] and board[a] != ' ':
            return board[a]
    if ' ' not in board:
        return 'tie'
    return None

def best_move(state, board, epsilon):
    available = [i for i in range(9) if board[i] == ' ']
    if random.random() < epsilon:
        return random.choice(available)
    q_values = [q_table.get((state, a), 0) for a in available]
    max_q = max(q_values)
    best = [a for a, q in zip(available, q_values) if q == max_q]
    return random.choice(best)

def update_q_table(prev_state, action, reward, new_state, done):
    old_q = q_table.get((prev_state, action), 0)
    future_q = 0 if done else max([q_table.get((new_state, a), 0)
                                   for a in range(9) if new_state[a] == ' '], default=0)
    q_table[(prev_state, action)] = old_q + ALPHA * (reward + GAMMA * future_q - old_q)

for episode in range(EPISODES):
    board = [' '] * 9
    state = get_state_key(board)
    done = False
    turn = 0

    while not done:
        move = best_move(state, board, EPSILON)
        board[move] = 'O'
        winner = check_winner(board)
        new_state = get_state_key(board)

        if winner:
            reward = 1 if winner == 'O' else -1 if winner == 'X' else 0.5
            update_q_table(state, move, reward, new_state, True)
            break

    
        opp_moves = [i for i in range(9) if board[i] == ' ']
        if not opp_moves:
            break
        opp_move = random.choice(opp_moves)
        board[opp_move] = 'X'
        winner = check_winner(board)
        if winner:
            reward = -1 if winner == 'X' else 1 if winner == 'O' else 0.5
            update_q_table(state, move, reward, get_state_key(board), True)
            break

        update_q_table(state, move, 0, get_state_key(board), False)
        state = get_state_key(board)

with open(Q_TABLE_FILE, "wb") as f:
    pickle.dump(q_table, f)

print("Training complete. Q-table saved.")
